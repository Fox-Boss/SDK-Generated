#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_GlobalTips_Pos.BP_STRUCT_GlobalTips_Pos
// 0x0008
struct FBP_STRUCT_GlobalTips_Pos
{
	int                                                x_0_BC95162242299DF7575384BF3165B2D9;                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                y_1_7244EB0D4A9825ADADE0B99F4A4761CB;                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

