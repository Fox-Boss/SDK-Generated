#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Reconnect_BP.Reconnect_BP_C.Construct
struct UReconnect_BP_C_Construct_Params
{
};

// Function Reconnect_BP.Reconnect_BP_C.ExecuteUbergraph_Reconnect_BP
struct UReconnect_BP_C_ExecuteUbergraph_Reconnect_BP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

