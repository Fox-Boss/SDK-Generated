#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct KantanChartsDatasource.KantanCartesianDatapoint
// 0x0008
struct FKantanCartesianDatapoint
{
	struct FVector2D                                   Coords;                                                   // 0x0000(0x0008) (Edit, BlueprintVisible, IsPlainOldData)
};

}

