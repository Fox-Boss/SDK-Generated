// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.Construct
// ()

void ULogin_UIPanelBG_2_C::Construct()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.Construct");

	ULogin_UIPanelBG_2_C_Construct_Params params;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


// Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.ExecuteUbergraph_Login_UIPanelBG_3
// (Net, NetReliable, NetRequest, Event, NetResponse, Static, NetMulticast, Public, NetServer, HasOutParms, HasDefaults, BlueprintCallable, BlueprintEvent, Const)
// Parameters:
// int                            EntryPoint                     (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)

void ULogin_UIPanelBG_2_C::STATIC_ExecuteUbergraph_Login_UIPanelBG_3(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.ExecuteUbergraph_Login_UIPanelBG_3");

	ULogin_UIPanelBG_2_C_ExecuteUbergraph_Login_UIPanelBG_3_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

