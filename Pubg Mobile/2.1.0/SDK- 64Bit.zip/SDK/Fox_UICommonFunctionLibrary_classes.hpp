#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// BlueprintGeneratedClass UICommonFunctionLibrary.UICommonFunctionLibrary_C
// 0x0000 (0x0028 - 0x0028)
class UUICommonFunctionLibrary_C : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("BlueprintGeneratedClass UICommonFunctionLibrary.UICommonFunctionLibrary_C");
		return pStaticClass;
	}


	void SetAdaptation_ScreenHole(class UWidget* Widget, class UObject* __WorldContext);
	void STATIC_SetIPXAdaptation(class UWidget* Widget, class UObject* __WorldContext);
	void STATIC_SetAdaptationByOffset(class UWidget* Widget, class UObject* __WorldContext);
	void SetAdaptation_Lobby(class UWidget* Widget, class UObject* __WorldContext);
	void FormatSecondsToString(int Seconds, class UObject* __WorldContext, struct FText* Ret);
	void STATIC_SetSquareFixedScslr(class UWidget* Widget, class UObject* __WorldContext);
	void STATIC_SetAdaptation(class UWidget* Widget, class UObject* __WorldContext);
	void SetTabStyle(bool isCheck, class UTextBlock* Text, class UImage* Icon, const struct FColor& onColor, const struct FColor& offColor, class UObject* __WorldContext);
};


}

