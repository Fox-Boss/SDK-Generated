#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_GlobalHelpTips_Pos.BP_STRUCT_GlobalHelpTips_Pos
// 0x0008
struct FBP_STRUCT_GlobalHelpTips_Pos
{
	int                                                y_0_4DBA1E404EED75A173CEF46903C67CB9;                     // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                x_1_4DB91E004EED75A073CEF46803C67CB8;                     // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

