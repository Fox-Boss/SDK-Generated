#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_GuidonConfig_type.BP_STRUCT_GuidonConfig_type
// 0x0050
struct FBP_STRUCT_GuidonConfig_type
{
	struct FString                                     GuidonName_0_12040E4023B2EFCB0015324407013B95;            // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     res_path_1_72570A001B373E7865688B400AE9C9B8;              // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     GuidonCode_2_2297CCC0696BD0B30003ADC60700F805;            // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     sort_key_3_6754908048CFD4FA607F307D00C800D9;              // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     res_path_small_4_259E2800594CF13823821BA90881FF9C;        // 0x0040(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

