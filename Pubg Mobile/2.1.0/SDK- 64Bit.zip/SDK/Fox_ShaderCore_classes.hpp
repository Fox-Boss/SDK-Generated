#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// Class ShaderCore.PrecompileShaderGameConfig
// 0x0060 (0x0088 - 0x0028)
class UPrecompileShaderGameConfig : public UObject
{
public:
	TArray<struct FGraphicsProfile>                    GraphicsProfiles;                                         // 0x0028(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0038(0x0018) MISSED OFFSET
	int                                                MobileEnableHardwarePCF;                                  // 0x0050(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileEnableIBL;                                          // 0x0054(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileEarlyZPass;                                         // 0x0058(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileEnableEarlyZDepthBias;                              // 0x005C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileUseAlphaToCoverage;                                 // 0x0060(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileBypassTranslucentMaterialPointLight;                // 0x0064(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileMSAA;                                               // 0x0068(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                AllowStaticLighting;                                      // 0x006C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                SupportAllShaderPermutations;                             // 0x0070(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                SupportLowQualityLightmaps;                               // 0x0074(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileEnableVertexPointLight;                             // 0x0078(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                MobileFallbackMSAAToFXAA;                                 // 0x007C(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	int                                                IndirectLightingCache;                                    // 0x0080(0x0004) (ZeroConstructor, Config, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0084(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class ShaderCore.PrecompileShaderGameConfig");
		return pStaticClass;
	}

};


// Class ShaderCore.ShaderGroupSettings
// 0x0078 (0x00A0 - 0x0028)
class UShaderGroupSettings : public UObject
{
public:
	TArray<struct FShaderGroupDesc>                    Groups_IOS;                                               // 0x0028(0x0010) (ZeroConstructor, Config)
	TArray<struct FShaderGroupDesc>                    Groups_AOS;                                               // 0x0038(0x0010) (ZeroConstructor, Config)
	unsigned char                                      UnknownData00[0x58];                                      // 0x0048(0x0058) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class ShaderCore.ShaderGroupSettings");
		return pStaticClass;
	}

};


}

