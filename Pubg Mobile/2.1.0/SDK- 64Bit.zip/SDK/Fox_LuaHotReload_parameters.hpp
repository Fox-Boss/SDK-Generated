#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function LuaHotReload.LuaHotReloadHelper.OnLuaFileHotUpdate
struct ULuaHotReloadHelper_OnLuaFileHotUpdate_Params
{
	struct FString                                     NotifyMessage;                                            // (Parm, ZeroConstructor)
};

}

