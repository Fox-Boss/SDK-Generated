#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_CorpsIconColor_type.BP_STRUCT_CorpsIconColor_type
// 0x0020
struct FBP_STRUCT_CorpsIconColor_type
{
	int                                                ID_0_52760C80425177D07DAE1F650BD163E4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                GNum_1_373F670000ACE8EC1AE46FEE01639E6D;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                RNum_2_6CDA49C06AA821FF1ACB3BEC01626E6D;                  // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                BNum_3_591045C044DDA06F1AEA692201636E6D;                  // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Color_4_02A7A9005D76F20C79AF79E8063C0072;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

