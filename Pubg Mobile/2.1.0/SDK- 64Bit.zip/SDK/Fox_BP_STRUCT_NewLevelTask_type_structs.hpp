#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_NewLevelTask_type.BP_STRUCT_NewLevelTask_type
// 0x0088
struct FBP_STRUCT_NewLevelTask_type
{
	int                                                TouristSwitch2_0_07F03A404907C74147D6D7AC0AEBF7E2;        // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Level_1_0F0B10C01F30D35763EAB4540563A09C;                 // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TouristSwitch1_2_07EF3A004907C74047D6D7AF0AEBF7E1;        // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x000C(0x0004) MISSED OFFSET
	struct FString                                     Task2Detail_3_61BB38C0398B095F4DEFFEE503E7423C;           // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     JumpTo2_4_171B770071C2E7202553E80100E88042;               // 0x0020(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Unlock_5_54330DC077D16E993B46B7F904B3F7CB;                // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Task2Award_6_3E5B5FC035CE93AF7BAA12770C3C66D4;            // 0x0040(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Award_7_63A86E802253655463E379D20559B4A4;                 // 0x0044(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Task2Cond_8_75434500020FE0D236016D4505C3EFA4;             // 0x0048(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                IOSSwitch1_9_72507640177498ED761F6C0B08957BF1;            // 0x004C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Task1Detail_10_22B2F8802B35ECB859A1B20000E7423C;          // 0x0050(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                IOSSwitch2_11_72517680177498EE761F6C0C08957BF2;           // 0x0060(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x0064(0x0004) MISSED OFFSET
	struct FString                                     JumpTo1_12_171A76C071C2E71F2553E80000E88041;              // 0x0068(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                Task1Cond_13_70D2C4C0008AB2212C1CB48805C0EFA4;            // 0x0078(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Task1Award_14_4AA6FF8023DBC7502297C6040C0C66D4;           // 0x007C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskTpye1_15_39750C4057DB62092A31AFDF062E3461;            // 0x0080(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                TaskTpye2_16_39760C8057DB620A2A31AFDE062E3462;            // 0x0084(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

