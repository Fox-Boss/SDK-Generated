#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function VersionUpdate_UIBP.VersionUpdate_UIBP_C.Construct
struct UVersionUpdate_UIBP_C_Construct_Params
{
};

// Function VersionUpdate_UIBP.VersionUpdate_UIBP_C.ExecuteUbergraph_VersionUpdate_UIBP
struct UVersionUpdate_UIBP_C_ExecuteUbergraph_VersionUpdate_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

