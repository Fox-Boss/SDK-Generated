#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct ShaderCore.GraphicsProfile
// 0x0030
struct FGraphicsProfile
{
	struct FName                                       FormatName;                                               // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	struct FName                                       FeatureLevel;                                             // 0x0008(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                QualityType;                                              // 0x0010(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                UserQualitySetting;                                       // 0x0014(0x0004) (ZeroConstructor, IsPlainOldData)
	struct FName                                       MaterialQualityLevel;                                     // 0x0018(0x0008) (ZeroConstructor, IsPlainOldData)
	int                                                MobileHDR;                                                // 0x0020(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MobileSimplerShader;                                      // 0x0024(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                ShadowQuality;                                            // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	int                                                MaxCSMShadowResolution;                                   // 0x002C(0x0004) (ZeroConstructor, IsPlainOldData)
};

// ScriptStruct ShaderCore.ShaderGroupDesc
// 0x0060
struct FShaderGroupDesc
{
	struct FString                                     Name;                                                     // 0x0000(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             Exclude;                                                  // 0x0010(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             Include;                                                  // 0x0020(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             IncludePath;                                              // 0x0030(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             Prerequisite;                                             // 0x0040(0x0010) (ZeroConstructor, Config)
	TArray<struct FString>                             Parent;                                                   // 0x0050(0x0010) (ZeroConstructor, Config)
};

}

