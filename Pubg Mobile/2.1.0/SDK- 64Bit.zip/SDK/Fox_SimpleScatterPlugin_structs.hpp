#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Enums
//---------------------------------------------------------------------------

// Enum SimpleScatterPlugin.EPropertyUpdateGroup
enum class EPropertyUpdateGroup : uint8_t
{
	InstancersPropertiesUpdate     = 0,
	ScatterUpdate                  = 1,
	TracedPointsUpdate             = 2,
	EverythingUpdate               = 3,
	EPropertyUpdateGroup_MAX       = 4
};


// Enum SimpleScatterPlugin.ESurfaceAlignMode
enum class ESurfaceAlignMode : uint8_t
{
	WorldAlign                     = 0,
	NormalAlign                    = 1,
	ESurfaceAlignMode_MAX          = 2
};


// Enum SimpleScatterPlugin.EScaleMode
enum class EScaleMode : uint8_t
{
	X                              = 0,
	XZ                             = 1,
	XYZ                            = 2,
	EScaleMode_MAX                 = 3
};


// Enum SimpleScatterPlugin.EDistributionMode
enum class EDistributionMode : uint8_t
{
	RandomDistribution             = 0,
	GridDistribution               = 1,
	EDistributionMode_MAX          = 2
};



//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// ScriptStruct SimpleScatterPlugin.InstancedMesh
// 0x0020
struct FInstancedMesh
{
	class UStaticMesh*                                 StaticMesh;                                               // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              ScaleMultiplier;                                          // 0x0008(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              Probability;                                              // 0x000C(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<EComponentMobility>                    Mobility;                                                 // 0x0010(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               bEnableCollision;                                         // 0x0011(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x6];                                       // 0x0012(0x0006) MISSED OFFSET
	class UHierarchicalInstancedStaticMeshComponent*   Instancer;                                                // 0x0018(0x0008) (ExportObject, ZeroConstructor, InstancedReference, IsPlainOldData)
};

// ScriptStruct SimpleScatterPlugin.ScatterSurface
// 0x0030
struct FScatterSurface
{
	class AActor*                                      Surface;                                                  // 0x0000(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	class UMaterial*                                   DistributionMaterial;                                     // 0x0008(0x0008) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	float                                              LandscapeUV_Size;                                         // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	TArray<struct FColor>                              DistributionTexture;                                      // 0x0018(0x0010) (ZeroConstructor)
	int                                                DistributionTextureSize;                                  // 0x0028(0x0004) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
};

// ScriptStruct SimpleScatterPlugin.SlopeDistributionLimit
// 0x0010
struct FSlopeDistributionLimit
{
	bool                                               bUseSlopeLimit;                                           // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              SlopeLimitOffset;                                         // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SlopeLimitContrast;                                       // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bSlopeLimitInvert;                                        // 0x000C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct SimpleScatterPlugin.HeightDistributionLimit
// 0x0010
struct FHeightDistributionLimit
{
	bool                                               bUseHeightLimit;                                          // 0x0000(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x0001(0x0003) MISSED OFFSET
	float                                              HeightLimitMin;                                           // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              HeightLimitMax;                                           // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               bHeightLimitInvert;                                       // 0x000C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct SimpleScatterPlugin.SlopeScaleFalloff
// 0x0010
struct FSlopeScaleFalloff
{
	float                                              SlopeFalloffEffect;                                       // 0x0000(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SlopeFalloffOffset;                                       // 0x0004(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	float                                              SlopeFalloffContrast;                                     // 0x0008(0x0004) (Edit, ZeroConstructor, IsPlainOldData)
	bool                                               SlopeFalloffInvert;                                       // 0x000C(0x0001) (Edit, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x3];                                       // 0x000D(0x0003) MISSED OFFSET
};

// ScriptStruct SimpleScatterPlugin.Bounds
// 0x0018
struct FBounds
{
	struct FVector                                     Origin;                                                   // 0x0000(0x000C) (IsPlainOldData)
	struct FVector                                     Extents;                                                  // 0x000C(0x000C) (IsPlainOldData)
};

// ScriptStruct SimpleScatterPlugin.TracedPoint
// 0x001C
struct FTracedPoint
{
	struct FVector                                     Location;                                                 // 0x0000(0x000C) (IsPlainOldData)
	struct FVector                                     Normal;                                                   // 0x000C(0x000C) (IsPlainOldData)
	struct FColor                                      TextureColor;                                             // 0x0018(0x0004) (IsPlainOldData)
};

// ScriptStruct SimpleScatterPlugin.GeneratedPoint
// 0x0010
struct FGeneratedPoint
{
	struct FVector                                     Location;                                                 // 0x0000(0x000C) (IsPlainOldData)
	float                                              Depth;                                                    // 0x000C(0x0004) (ZeroConstructor, IsPlainOldData)
};

}

