#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct BP_STRUCT_StatEventType_type.BP_STRUCT_StatEventType_type
// 0x0014
struct FBP_STRUCT_StatEventType_type
{
	struct FString                                     DisplayName_0_7D516B402CBFB7AB2A776EB00D8D1405;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_1_49A788C0256E4AF90B9DAE5205E4F254;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

