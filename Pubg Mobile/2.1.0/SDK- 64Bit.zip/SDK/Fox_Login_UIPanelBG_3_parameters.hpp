#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.Construct
struct ULogin_UIPanelBG_2_C_Construct_Params
{
};

// Function Login_UIPanelBG_3.Login_UIPanelBG_2_C.ExecuteUbergraph_Login_UIPanelBG_3
struct ULogin_UIPanelBG_2_C_ExecuteUbergraph_Login_UIPanelBG_3_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

