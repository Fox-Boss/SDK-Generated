# Pubg-2.1-IOS-SDK
Pubg 2.1 SDK for IOS IPhone and IPad (ARM64) UE4 engine.
Tested only on architecture AArch64 or ARM64, Dumped from IPhone11. I do not know if it work for others architecture.[14-7-2022]


 * This SDK For Unreal Engine 4 UE4 ((( Pubg 2.1 ))) 
 * THIS ONLY FOR IOS IPhone or IPAD
 * what you need for ESP (radar or xray ) is this:
 * UWorld :0x102517d5c / 0x1081c6318 
 * FName : 0x103a56e94 / 0x107e3cb10 
* ALl Pubg Headers in one zip folder 
* All what you need to make FUN with the game ;)
* If you like to develop Pubg ESP or whatever menu for IOS IPhone or IPad this is the right information you need 
* 
---------------------------------------------
##### headers_dump
* C++ headers that you can use in your source, however the headers might not compile directly without a change

##### FullDump.hpp
* An all-in-one dump file

##### logs.txt
* Logfile containing dump process logs

##### objects_dump.txt
* ObjObjects dump

##### script.json
* If you are familiar with Il2cppDumper script.json, this is similar
* It contains a json array of function names and addresses


------------------



