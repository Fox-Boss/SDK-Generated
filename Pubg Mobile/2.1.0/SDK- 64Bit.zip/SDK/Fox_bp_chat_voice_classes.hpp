#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

namespace SDK
{
//---------------------------------------------------------------------------
//Classes
//---------------------------------------------------------------------------

// ScriptBlueprintGeneratedClass bp_chat_voice.bp_chat_voice_C
// 0x00F0 (0x0530 - 0x0440)
class Abp_chat_voice_C : public ALuaClassObj
{
public:
	class UScriptContextComponent*                     Generated_ScriptContext;                                  // 0x0440(0x0008) (BlueprintVisible, ZeroConstructor, InstancedReference, IsPlainOldData)
	int                                                BP_GlobalChatvoiceCurrentMode;                            // 0x0448(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x044C(0x0004) MISSED OFFSET
	struct FString                                     BP_GlobalChatvoiceCurrentPlayFile;                        // 0x0450(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	TArray<struct FBP_STRUCT_GlobalChatvoiceDownloadData> BP_ARRAY_GlobalChatvoiceDownloadList;                     // 0x0460(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FBP_STRUCT_GlobalChatvoiceDownloadData      BP_STRUCT_GlobalChatvoiceDownloadData;                    // 0x0470(0x0040) (Edit, BlueprintVisible)
	bool                                               BP_GlobalChatvoiceSpeakerOpened;                          // 0x04B0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x7];                                       // 0x04B1(0x0007) MISSED OFFSET
	struct FString                                     BP_GlobalChatvoiceUploadMsgId;                            // 0x04B8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               BP_GlobalChatvoiceRecordSuccess;                          // 0x04C8(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x7];                                       // 0x04C9(0x0007) MISSED OFFSET
	struct FString                                     BP_GlobalChatvoiceCurrentRoom;                            // 0x04D0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     BP_GlobalChatvoiceCurrentRole;                            // 0x04E0(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	bool                                               BP_GlobalChatvoiceMicOpened;                              // 0x04F0(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData03[0x7];                                       // 0x04F1(0x0007) MISSED OFFSET
	struct FString                                     BP_GlobalChatvoiceToTextContent;                          // 0x04F8(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                BP_GlobalChatvoiceUploadTime;                             // 0x0508(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BP_GlobalChatvoiceIsTeamup;                               // 0x050C(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	bool                                               BP_GlobalChatvoiceDefaultOpenTeam;                        // 0x050D(0x0001) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData04[0x2];                                       // 0x050E(0x0002) MISSED OFFSET
	struct FString                                     BP_GlobalChatvoiceCurrentStage;                           // 0x0510(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                BP_GlobalChatvoiceTotalLimit;                             // 0x0520(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData05[0x4];                                       // 0x0524(0x0004) MISSED OFFSET
	class USceneComponent*                             DefaultSceneRoot;                                         // 0x0528(0x0008) (BlueprintVisible, ZeroConstructor, IsPlainOldData)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("ScriptBlueprintGeneratedClass bp_chat_voice.bp_chat_voice_C");
		return pStaticClass;
	}


	void EventUploadGVoiceRecord_NoFetch();
	void EventUploadGVoiceRecord();
	void EventStartPlayGVoiceRecord_NoFetch();
	void EventStartPlayGVoiceRecord();
	void EventNotifySystemMicOpen_NoFetch();
	void EventNotifySystemMicOpen();
	void EventChangeGVoiceMode_NoFetch();
	void EventChangeGVoiceMode();
	void EventCheckOpenMicFail_NoFetch();
	void EventCheckOpenMicFail();
	void EventStopGVoiceRecord_NoFetch();
	void EventStopGVoiceRecord();
	void EventCancelGVoiceRecord_NoFetch();
	void EventCancelGVoiceRecord();
	void EventChatVoiceFetchInfo_NoFetch();
	void EventChatVoiceFetchInfo();
	void EventTickVoiceRoom_NoFetch();
	void EventTickVoiceRoom();
	void EventNotifyVoiceOpenSpeaker_NoFetch();
	void EventNotifyVoiceOpenSpeaker();
	void EventOnTryOpenMic_NoFetch();
	void EventOnTryOpenMic();
	void EventNotifyVoiceChatFailToRecord_NoFetch();
	void EventNotifyVoiceChatFailToRecord();
	void EventClearGVoiceProcedure_NoFetch();
	void EventClearGVoiceProcedure();
	void EventNotifySystemVoiceOpen_NoFetch();
	void EventNotifySystemVoiceOpen();
	void EventNotifySystemSpeakerOpen_NoFetch();
	void EventNotifySystemSpeakerOpen();
	void EventNotifyDownloadFailed_NoFetch();
	void EventNotifyDownloadFailed();
	void EventMicClickCD_NoFetch();
	void EventMicClickCD();
	void EventNotifyVoiceRecordTooShort_NoFetch();
	void EventNotifyVoiceRecordTooShort();
	void EventNotifyRecordTooShort_NoFetch();
	void EventNotifyRecordTooShort();
	void EventStartGVoiceRecord_NoFetch();
	void EventStartGVoiceRecord();
	void EventChangeMicState_NoFetch();
	void EventChangeMicState();
	void EventNotifyVoiceProcedureFailed_NoFetch();
	void EventNotifyVoiceProcedureFailed();
	void EventStopPlayGVoiceRecord_NoFetch();
	void EventStopPlayGVoiceRecord();
	void EventChatRequestPrivacy_NoFetch();
	void EventChatRequestPrivacy();
	void EventChangeSpeakerState_NoFetch();
	void EventChangeSpeakerState();
	void EventChangeLobbyRoomState_NoFetch();
	void EventChangeLobbyRoomState();
	void EventCheckOpenMicSuc_NoFetch();
	void EventCheckOpenMicSuc();
	void EventChatRequestPrivacyPre_NoFetch();
	void EventChatRequestPrivacyPre();
	void EventChatVoiceSetInfo_Push_NoFetch();
	void EventChatVoiceSetInfo_Push();
	void UserConstructionScript();
};


}

