#pragma once

// Pubg Mobile (2.1.0) SDKGenerator by @FoO_X

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function Login_UIBP.Login_UIBP_C.SetRenderTransformWheniPhone
struct ULogin_UIBP_C_SetRenderTransformWheniPhone_Params
{
};

// Function Login_UIBP.Login_UIBP_C.Construct
struct ULogin_UIBP_C_Construct_Params
{
};

// Function Login_UIBP.Login_UIBP_C.ExecuteUbergraph_Login_UIBP
struct ULogin_UIBP_C_ExecuteUbergraph_Login_UIBP_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

